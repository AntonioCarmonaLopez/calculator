# calculator
calc with some functions in c#
